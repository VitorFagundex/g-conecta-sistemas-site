# G Conecta Sistemas - Site Profissional

## 📋 Instruções de Uso

Este é um site profissional completo para a **G Conecta Sistemas**, desenvolvido com **React 19 + Tailwind CSS 4**.

### 🚀 Como Instalar e Rodar Localmente

1. **Instale as dependências:**
   ```bash
   cd g-conecta-sistemas
   pnpm install
   ```

2. **Inicie o servidor de desenvolvimento:**
   ```bash
   pnpm dev
   ```

3. **Acesse no navegador:**
   ```
   http://localhost:3000
   ```

### 📝 Como Editar o Site

Todos os elementos editáveis têm comentários claros no código. Procure por:

#### **Número do WhatsApp**
- Arquivo: `client/src/pages/Home.tsx` (linha 30)
- Procure por: `WHATSAPP_NUMERO`
- Altere para seu número: `"5575983349174"` → seu número

#### **Textos e Conteúdo**
- Arquivo: `client/src/pages/Home.tsx`
- Cada seção tem comentários indicando onde alterar
- Procure por comentários com "ALTERAR AQUI"

#### **Informações das Soluções**
- Arquivo: `client/src/components/SolutionModal.tsx`
- Procure por: `SOLUÇÕES_DETALHES`
- Altere nome, preço, descrição, benefícios e recursos

#### **Link do Instagram**
- Arquivo: `client/src/components/Footer.tsx`
- Procure por: `@gconecta`
- Altere para seu perfil

#### **Cores e Tema**
- Arquivo: `client/src/index.css`
- Edite as variáveis CSS para mudar cores globalmente
- Procure por: `:root { ... }`

### 🎨 Estrutura de Pastas

```
g-conecta-sistemas/
├── client/
│   ├── public/          # Imagens e assets estáticos
│   ├── src/
│   │   ├── pages/       # Páginas (Home.tsx)
│   │   ├── components/  # Componentes reutilizáveis
│   │   ├── App.tsx      # Arquivo principal
│   │   └── index.css    # Estilos globais
│   └── index.html       # HTML principal
├── package.json         # Dependências
└── README-INSTRUCOES.md # Este arquivo
```

### 🔧 Funcionalidades Implementadas

✅ **Menu Fixo** - Navegação fluida com links para seções
✅ **Hero Section** - Apresentação com CTA para WhatsApp
✅ **Sobre** - 3 cards com Inovação, Segurança e Suporte
✅ **Provas Sociais** - 3 depoimentos de clientes
✅ **Soluções** - 6 produtos com modal de detalhes completo
✅ **Segmentos** - 8 setores atendidos
✅ **ChatBot** - Coleta dados e envia para WhatsApp
✅ **Modal** - Detalhes completos de cada solução
✅ **Footer** - Links de contato e Instagram

### 📱 Responsividade

O site é totalmente responsivo:
- ✅ Desktop (1024px+)
- ✅ Tablet (768px - 1023px)
- ✅ Mobile (< 768px)

### 🔐 Informações Importantes

- **Número WhatsApp:** Altere em `Home.tsx` linha 30
- **Integração WhatsApp:** Todos os CTAs enviam para WhatsApp automaticamente
- **ChatBot:** Coleta nome, empresa, segmento e necessidade, depois envia para WhatsApp
- **Modal:** Clique em "Saiba Mais" para ver detalhes completos de cada solução

### 🚀 Deploy

Para fazer deploy do site:

1. **Build para produção:**
   ```bash
   pnpm build
   ```

2. **Preview do build:**
   ```bash
   pnpm preview
   ```

3. **Fazer deploy:**
   - Use Vercel, Netlify, Railway ou outro serviço de hosting
   - Ou use a plataforma Manus (recomendado)

### 📞 Suporte

Se precisar de ajuda:
- Verifique os comentários no código
- Procure por "ALTERAR AQUI" para elementos editáveis
- Todos os arquivos têm documentação em português

---

**Desenvolvido com ❤️ para G Conecta Sistemas**
