# 🎯 Guia Rápido de Edição

## Alterações Mais Comuns

### 1️⃣ Alterar Número do WhatsApp

**Arquivo:** `client/src/pages/Home.tsx`  
**Linha:** 30

```javascript
// ANTES:
const WHATSAPP_NUMERO = "5575983349174";

// DEPOIS:
const WHATSAPP_NUMERO = "seu_numero_aqui";
```

### 2️⃣ Alterar Nome da Empresa

**Arquivo:** `client/src/components/Header.tsx`

```javascript
// Procure por "G Conecta" e altere para seu nome
```

### 3️⃣ Alterar Preços das Soluções

**Arquivo:** `client/src/components/SolutionModal.tsx`  
**Procure por:** `SOLUTIONS_DETAILS`

```javascript
'g-pro': {
  price: 'A partir de R$ 119,99',  // ← Altere aqui
  // ...
}
```

### 4️⃣ Alterar Descrição das Soluções

**Arquivo:** `client/src/components/SolutionModal.tsx`

```javascript
'g-pro': {
  description: 'Uma solução integrada e sólida...',  // ← Altere aqui
  // ...
}
```

### 5️⃣ Alterar Link do Instagram

**Arquivo:** `client/src/components/Footer.tsx`

```javascript
// Procure por "@gconecta" e altere para seu perfil
```

### 6️⃣ Alterar Cores do Site

**Arquivo:** `client/src/index.css`

```css
:root {
  --primary: var(--color-blue-700);  /* Cor primária */
  --secondary: oklch(0.98 0.001 286.375);  /* Cor secundária */
  /* ... outras cores ... */
}
```

### 7️⃣ Alterar Depoimentos

**Arquivo:** `client/src/pages/Home.tsx`  
**Procure por:** "O que Nossos Clientes Dizem"

```javascript
<p className="text-gray-700 mb-4">
  "Seu depoimento aqui"  // ← Altere o texto
</p>
<p className="font-bold text-gray-900">Seu Nome</p>
<p className="text-sm text-gray-600">Seu Cargo - Sua Empresa</p>
```

### 8️⃣ Alterar Segmentos Atendidos

**Arquivo:** `client/src/pages/Home.tsx`  
**Procure por:** "Segmentos Atendidos"

```javascript
<div className="text-4xl mb-3">🏪</div>  {/* Emoji */}
<h3 className="font-bold text-gray-900 mb-1">Varejo</h3>  {/* Nome */}
<p className="text-sm text-gray-600">Lojas e comércios</p>  {/* Descrição */}
```

---

## 📱 Testar Responsividade

1. Abra o navegador (F12)
2. Clique em "Toggle device toolbar" (Ctrl+Shift+M)
3. Teste em diferentes tamanhos

---

## 🚀 Após Fazer Alterações

1. **Salve o arquivo** (Ctrl+S)
2. **O site atualiza automaticamente** no navegador
3. **Teste no mobile** também!

---

## ⚠️ Cuidados Importantes

- ❌ Não delete chaves `{}` ou parênteses `()`
- ❌ Não remova comentários importantes
- ❌ Sempre use aspas duplas `"` ou backticks `` ` ``
- ✅ Mantenha a indentação correta
- ✅ Teste após cada alteração

---

## 🐛 Se Algo Quebrar

1. Procure por erros no console (F12)
2. Verifique se fechou todas as tags
3. Verifique se não deletou chaves ou parênteses
4. Recarregue a página (Ctrl+R)

---

**Dúvidas? Verifique os comentários no código!**
