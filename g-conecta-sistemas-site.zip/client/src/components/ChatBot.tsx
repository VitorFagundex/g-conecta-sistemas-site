import { useState, useEffect } from 'react';
import { MessageCircle, X, Send } from 'lucide-react';

/**
 * COMPONENTE: ChatBot
 * 
 * Função: Chatbot consultivo que recomenda soluções baseado no segmento do cliente
 * 
 * FLUXO DO CHATBOT:
 * 1. Boas-vindas automáticas (ao abrir o chat)
 * 2. Pergunta o nome do cliente
 * 3. Pergunta o segmento da empresa
 * 4. Recomenda solução automaticamente baseado no segmento
 * 5. Explica benefícios da solução
 * 6. Pergunta se deseja mais informações
 * 7. Se SIM: coleta WhatsApp e envia para atendente
 * 
 * COMO EDITAR:
 * 1. Para alterar o número do WhatsApp: procure por "NÚMERO DO WHATSAPP" abaixo
 * 2. Para alterar segmentos e recomendações: procure por "MAPEAMENTO DE SEGMENTOS" abaixo
 * 3. Para alterar mensagens: procure por "MENSAGENS" abaixo
 */

// ========================================
// NÚMERO DO WHATSAPP - ALTERAR AQUI
// ========================================
const WHATSAPP_NUMERO = "5575983349174";

// ========================================
// MAPEAMENTO DE SEGMENTOS PARA SOLUÇÕES
// Cada segmento é mapeado para uma solução recomendada
// ALTERAR AQUI se necessário
// ========================================
const SEGMENTOS_SOLUCOES = {
  varejo: {
    nome: 'Varejo',
    solucao: 'G Pro',
    descricao: 'O G Pro é perfeito para lojas e comércios! Ele oferece gestão completa de estoque, vendas e clientes. Com relatórios avançados, você acompanha tudo em tempo real.',
    beneficios: ['Gestão de estoque integrada', 'Controle de vendas', 'Relatórios de desempenho', 'Suporte prioritário'],
  },
  saude: {
    nome: 'Saúde',
    solucao: 'G Jatus',
    descricao: 'O G Jatus é ideal para clínicas e consultórios! Aplicativo mobile para iOS e Android que facilita agendamentos automáticos e notificações para seus pacientes.',
    beneficios: ['Agendamentos automáticos', 'Notificações push', 'Disponível em iOS e Android', 'Fácil de usar'],
  },
  clinica: {
    nome: 'Clínica',
    solucao: 'G Jatus',
    descricao: 'O G Jatus é ideal para clínicas e consultórios! Aplicativo mobile para iOS e Android que facilita agendamentos automáticos e notificações para seus pacientes.',
    beneficios: ['Agendamentos automáticos', 'Notificações push', 'Disponível em iOS e Android', 'Fácil de usar'],
  },
  consultorio: {
    nome: 'Consultório',
    solucao: 'G Jatus',
    descricao: 'O G Jatus é ideal para consultórios! Aplicativo mobile para iOS e Android que facilita agendamentos automáticos e notificações para seus pacientes.',
    beneficios: ['Agendamentos automáticos', 'Notificações push', 'Disponível em iOS e Android', 'Fácil de usar'],
  },
  salao: {
    nome: 'Salão',
    solucao: 'G Jatus',
    descricao: 'O G Jatus é perfeito para salões e spas! Gerencia agendamentos de forma automática e envia notificações aos clientes via app mobile.',
    beneficios: ['Agendamentos automáticos', 'Notificações push', 'Disponível em iOS e Android', 'Fácil de usar'],
  },
  spa: {
    nome: 'Spa',
    solucao: 'G Jatus',
    descricao: 'O G Jatus é perfeito para spas! Gerencia agendamentos de forma automática e envia notificações aos clientes via app mobile.',
    beneficios: ['Agendamentos automáticos', 'Notificações push', 'Disponível em iOS e Android', 'Fácil de usar'],
  },
  restaurante: {
    nome: 'Restaurante',
    solucao: 'G Pro',
    descricao: 'O G Pro é excelente para restaurantes e bares! Controla pedidos, estoque, mesas e clientes. Com relatórios detalhados, você gerencia tudo facilmente.',
    beneficios: ['Gestão de pedidos', 'Controle de estoque', 'Gestão de mesas', 'Relatórios de vendas'],
  },
  bar: {
    nome: 'Bar',
    solucao: 'G Pro',
    descricao: 'O G Pro é excelente para bares! Controla pedidos, estoque e clientes. Com relatórios detalhados, você gerencia tudo facilmente.',
    beneficios: ['Gestão de pedidos', 'Controle de estoque', 'Gestão de clientes', 'Relatórios de vendas'],
  },
  hotel: {
    nome: 'Hotel',
    solucao: 'G Pro',
    descricao: 'O G Pro é ideal para hotéis e pousadas! Gerencia reservas, hóspedes, check-in/out e faturamento de forma integrada.',
    beneficios: ['Gestão de reservas', 'Controle de hóspedes', 'Faturamento integrado', 'Relatórios de ocupação'],
  },
  pousada: {
    nome: 'Pousada',
    solucao: 'G Pro',
    descricao: 'O G Pro é ideal para pousadas! Gerencia reservas, hóspedes, check-in/out e faturamento de forma integrada.',
    beneficios: ['Gestão de reservas', 'Controle de hóspedes', 'Faturamento integrado', 'Relatórios de ocupação'],
  },
  escola: {
    nome: 'Escola',
    solucao: 'G Pro',
    descricao: 'O G Pro é perfeito para escolas e cursos! Gerencia alunos, turmas, notas e comunicação com pais de forma centralizada.',
    beneficios: ['Gestão de alunos', 'Controle de turmas', 'Notas e frequência', 'Comunicação com pais'],
  },
  curso: {
    nome: 'Curso',
    solucao: 'G Pro',
    descricao: 'O G Pro é perfeito para cursos! Gerencia alunos, turmas, notas e comunicação de forma centralizada.',
    beneficios: ['Gestão de alunos', 'Controle de turmas', 'Notas e frequência', 'Comunicação com alunos'],
  },
  oficina: {
    nome: 'Oficina',
    solucao: 'G Pro',
    descricao: 'O G Pro é excelente para oficinas! Gerencia ordens de serviço, clientes, peças e faturamento de forma integrada.',
    beneficios: ['Ordens de serviço', 'Controle de clientes', 'Gestão de peças', 'Faturamento integrado'],
  },
  concessionaria: {
    nome: 'Concessionária',
    solucao: 'G Pro',
    descricao: 'O G Pro é ideal para concessionárias! Gerencia vendas, clientes, estoque de veículos e serviços de forma completa.',
    beneficios: ['Gestão de vendas', 'Controle de clientes', 'Estoque de veículos', 'Serviços integrados'],
  },
  servicos: {
    nome: 'Serviços',
    solucao: 'G Slim',
    descricao: 'O G Slim é perfeito para empresas de serviços! Solução enxuta e ágil que gerencia projetos, clientes e faturamento.',
    beneficios: ['Gestão de projetos', 'Controle de clientes', 'Faturamento simples', 'Fácil de usar'],
  },
  empresa: {
    nome: 'Empresa',
    solucao: 'G Pro',
    descricao: 'O G Pro é completo para gestão corporativa! Oferece todos os recursos necessários para gerenciar sua empresa com eficiência.',
    beneficios: ['Gestão completa', 'Relatórios avançados', 'Suporte prioritário', 'Escalável'],
  },
};

interface ChatMessage {
  type: 'bot' | 'user';
  text: string;
}

interface ChatData {
  nome?: string;
  segmento?: string;
  whatsapp?: string;
}

type ChatStep = 'welcome' | 'nome' | 'segmento' | 'recomendacao' | 'interesse' | 'whatsapp' | 'finalizado';

export default function ChatBot() {
  // Estado do chatbot
  const [isOpen, setIsOpen] = useState(false);
  const [currentStep, setCurrentStep] = useState<ChatStep>('welcome');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [chatData, setChatData] = useState<ChatData>({});
  const [recomendacaoSolucao, setRecomendacaoSolucao] = useState<any>(null);

  // Função para adicionar mensagem ao chat
  const adicionarMensagem = (type: 'bot' | 'user', text: string) => {
    setMessages(prev => [...prev, { type, text }]);
  };

  // Função para enviar dados para WhatsApp
  const enviarParaWhatsApp = (dados: ChatData) => {
    const mensagem = `
*Novo Lead - G Conecta Sistemas*

👤 *Nome:* ${dados.nome}
🏢 *Segmento:* ${dados.segmento}
📱 *WhatsApp:* ${dados.whatsapp}
🎯 *Solução Recomendada:* ${recomendacaoSolucao?.solucao}

Responda este cliente via WhatsApp!
    `.trim();

    const mensagemCodificada = encodeURIComponent(mensagem);
    window.open(
      `https://wa.me/${WHATSAPP_NUMERO}?text=${mensagemCodificada}`,
      '_blank'
    );
  };

  // Função para processar resposta do usuário
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!inputValue.trim()) return;

    // Adicionar mensagem do usuário
    adicionarMensagem('user', inputValue);

    // Processar resposta baseado no step atual
    if (currentStep === 'nome') {
      setChatData({ ...chatData, nome: inputValue });
      setCurrentStep('segmento');
      setTimeout(() => {
        adicionarMensagem('bot', 'Qual é o segmento da sua empresa? (comércio, serviços, clínica, salão, hotel, restaurante, etc.)');
      }, 500);
    } else if (currentStep === 'segmento') {
      const segmentoNormalizado = inputValue.toLowerCase().trim();
      const solucaoRecomendada = SEGMENTOS_SOLUCOES[segmentoNormalizado as keyof typeof SEGMENTOS_SOLUCOES];

      if (solucaoRecomendada) {
        setChatData({ ...chatData, segmento: inputValue });
        setRecomendacaoSolucao(solucaoRecomendada);
        setCurrentStep('recomendacao');
        
        setTimeout(() => {
          adicionarMensagem('bot', solucaoRecomendada.descricao);
          setTimeout(() => {
            const beneficiosTexto = solucaoRecomendada.beneficios.map(b => `✓ ${b}`).join('\n');
            adicionarMensagem('bot', `Principais benefícios:\n${beneficiosTexto}\n\nGostaria de receber mais informações sobre esse sistema?`);
          }, 800);
        }, 500);
      } else {
        adicionarMensagem('bot', 'Desculpe, não reconheci esse segmento. Pode tentar novamente? (Exemplos: varejo, saúde, restaurante, hotel, etc.)');
      }
    } else if (currentStep === 'recomendacao') {
      const resposta = inputValue.toLowerCase().trim();
      if (resposta === 'sim' || resposta === 's' || resposta === 'yes' || resposta === 'y') {
        setChatData({ ...chatData, segmento: chatData.segmento });
        setCurrentStep('whatsapp');
        setTimeout(() => {
          adicionarMensagem('bot', 'Ótimo! Para que um atendente entre em contato com você, qual é seu WhatsApp? (com DDD, ex: 75 98334-9174)');
        }, 500);
      } else if (resposta === 'não' || resposta === 'nao' || resposta === 'n' || resposta === 'no') {
        setCurrentStep('finalizado');
        setTimeout(() => {
          adicionarMensagem('bot', 'Tudo bem! Se mudar de ideia, estaremos aqui para ajudar. Você pode clicar no botão do chat a qualquer momento. 😊');
        }, 500);
      } else {
        adicionarMensagem('bot', 'Por favor, responda com "Sim" ou "Não".');
      }
    } else if (currentStep === 'whatsapp') {
      const whatsappFormatado = inputValue.replace(/\D/g, '');
      if (whatsappFormatado.length >= 10) {
        setChatData({ ...chatData, whatsapp: whatsappFormatado });
        setCurrentStep('finalizado');
        
        setTimeout(() => {
          adicionarMensagem('bot', 'Perfeito! Um atendente entrará em contato com você pelo WhatsApp para explicar todos os detalhes. Obrigado por confiar na G Conecta Sistemas! 🎉');
          setIsLoading(true);
          setTimeout(() => {
            enviarParaWhatsApp({ ...chatData, whatsapp: whatsappFormatado });
            setIsLoading(false);
          }, 1000);
        }, 500);
      } else {
        adicionarMensagem('bot', 'WhatsApp inválido. Por favor, digite um número válido com DDD (ex: 75 98334-9174)');
      }
    }

    setInputValue('');
  };

  // Função para abrir o chatbot
  const handleOpen = () => {
    setIsOpen(true);
    if (messages.length === 0) {
      // Primeira vez abrindo - mostrar boas-vindas
      setTimeout(() => {
        adicionarMensagem('bot', 'Olá! 👋 Bem-vindo à G Conecta Sistemas!');
        setTimeout(() => {
          adicionarMensagem('bot', 'Somos especializados em soluções de software para diversos tipos de negócio. Para começar, qual é o seu nome?');
          setCurrentStep('nome');
        }, 800);
      }, 300);
    }
  };

  // Função para fechar chatbot
  const handleClose = () => {
    setIsOpen(false);
  };

  // Função para resetar chatbot
  const handleReset = () => {
    setMessages([]);
    setCurrentStep('welcome');
    setChatData({});
    setRecomendacaoSolucao(null);
    setInputValue('');
  };

  return (
    <>
      {/* BOTÃO FLUTUANTE DO CHATBOT */}
      <button
        onClick={() => isOpen ? handleClose() : handleOpen()}
        className="fixed bottom-6 right-6 bg-orange-600 text-white rounded-full p-4 shadow-lg hover:bg-orange-700 transition-all duration-200 z-40"
        aria-label="Abrir chat"
      >
        {isOpen ? (
          <X size={24} />
        ) : (
          <MessageCircle size={24} />
        )}
      </button>

      {/* JANELA DO CHATBOT */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 w-96 bg-white rounded-lg shadow-2xl z-40 flex flex-col max-h-[500px]">
          
          {/* CABEÇALHO DO CHATBOT */}
          <div className="bg-orange-600 text-white p-4 rounded-t-lg">
            <h3 className="font-bold text-lg">Chat G Conecta</h3>
            <p className="text-sm text-orange-100">Estamos aqui para ajudar!</p>
          </div>

          {/* CORPO DO CHATBOT - MENSAGENS */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.length === 0 ? (
              <div className="text-center text-gray-500 py-8">
                <p className="text-sm">Clique em enviar para começar a conversa</p>
              </div>
            ) : (
              messages.map((msg, idx) => (
                <div
                  key={idx}
                  className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-xs px-3 py-2 rounded-lg text-sm ${
                      msg.type === 'user'
                        ? 'bg-orange-600 text-white rounded-br-none'
                        : 'bg-gray-100 text-gray-800 rounded-bl-none'
                    }`}
                  >
                    {msg.text.split('\n').map((line, i) => (
                      <div key={i}>{line}</div>
                    ))}
                  </div>
                </div>
              ))
            )}
          </div>

          {/* FORMULÁRIO DE ENTRADA */}
          <form onSubmit={handleSubmit} className="border-t border-gray-200 p-4">
            <div className="flex gap-2">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Digite sua resposta..."
                className="flex-1 border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-orange-600 text-sm"
                disabled={isLoading || currentStep === 'finalizado'}
              />
              <button
                type="submit"
                disabled={isLoading || !inputValue.trim() || currentStep === 'finalizado'}
                className="bg-orange-600 text-white rounded-lg p-2 hover:bg-orange-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <div className="animate-spin">⏳</div>
                ) : (
                  <Send size={20} />
                )}
              </button>
            </div>

            {/* BOTÃO PARA RESETAR */}
            {currentStep === 'finalizado' && (
              <button
                type="button"
                onClick={handleReset}
                className="mt-2 text-sm text-gray-500 hover:text-gray-700 w-full text-center"
              >
                Começar nova conversa
              </button>
            )}
          </form>
        </div>
      )}
    </>
  );
}
