import { X } from 'lucide-react';

/**
 * COMPONENTE: SolutionModal
 * 
 * Função: Modal que exibe detalhes completos de uma solução
 * 
 * COMO EDITAR:
 * 1. Para alterar informações de cada solução: procure por "SOLUÇÕES_DETALHES" abaixo
 * 2. Para alterar o número do WhatsApp: procure por "WHATSAPP_NUMERO"
 * 3. Para alterar cores: edite o arquivo client/src/index.css
 */

interface SolutionModalProps {
  isOpen: boolean;
  onClose: () => void;
  solution: {
    id: string;
    name: string;
    price: string;
    description: string;
    modules?: string[];
    whatsappLink: string;
  };
}

// ========================================
// SOLUÇÕES_DETALHES - Conteúdo completo
// ALTERAR AQUI para atualizar informações
// ========================================
const SOLUTIONS_DETAILS: { [key: string]: any } = {
  'g-pro': {
    id: 'g-pro',
    name: 'G Pro',
    price: 'A partir de R$ 119,99',
    subtitle: 'Uma solução integrada e sólida para a gestão do varejo brasileiro',
    description: 'O G Pro conecta compras, estoque, emissão fiscal e financeiro em um sistema robusto, projetado para dar consistência às operações do varejo.',
    mainBenefits: [
      {
        title: 'Gestão financeira completa',
        description: 'Ferramentas que centralizam informações financeiras para suporte à tomada de decisão e à operação diária.'
      },
      {
        title: 'Emissão fiscal rápida e segura',
        description: 'Atendimento a diferentes modelos de operação, com foco em conformidade fiscal e sem limite mensal.'
      },
      {
        title: 'Vendas ágeis e precisas',
        description: 'Integração com TEF, PIX, PDV móvel e balanças, reduzindo erros de caixa e acelerando o atendimento no PDV.'
      },
      {
        title: 'Controle total de estoque',
        description: 'Visibilidade e controle dos níveis de estoque de forma prática e integrada.'
      }
    ],
    resources: [
      'Sem limites de emissão de notas',
      'Integração com TEF, PIX e balanças',
      'Importação de XML para agilizar compras',
      'Mais de 400 relatórios estratégicos',
      'Envio automático de XML para a contabilidade',
      'Geração de arquivos fiscais'
    ],
    segments: 'Uma solução flexível, preparada para diferentes segmentos do varejo.'
  },
  'g-slim': {
    id: 'g-slim',
    name: 'G Slim',
    price: 'A partir de R$ 69,99',
    subtitle: 'Sistema simples para vendas e emissão fiscal no varejo',
    description: 'O G Slim é uma solução compacta, indicada para operações que buscam agilidade na venda, simplicidade no uso e conformidade fiscal no dia a dia.',
    mainBenefits: [
      {
        title: 'Cadastro e operação',
        description: 'Cadastro facilitado de clientes e produtos, leitura de código de barras, busca automática por CNPJ ou CEP.'
      },
      {
        title: 'Estoque',
        description: 'Controle de estoque simplificado com organização sem complexidade excessiva.'
      },
      {
        title: 'Vendas e PDV',
        description: 'Frente de caixa ágil com precisão e fluidez no atendimento.'
      },
      {
        title: 'Relatórios',
        description: 'Relatórios operacionais para acompanhamento das vendas.'
      }
    ],
    resources: [
      'Ativação simples e rápida',
      'Emissão de NF-e e NFC-e sem limite mensal',
      'Integração com PIX, balanças e periféricos',
      'Importação de notas para agilizar cadastros',
      'Envio automático de XML para a contabilidade'
    ],
    segments: 'Ideal para operações de varejo com processos simplificados.'
  },
  'g-micro': {
    id: 'g-micro',
    name: 'G Micro',
    price: 'A partir de R$ 89,99',
    subtitle: 'Sistema completo para microempreendedores',
    description: 'O G Micro é um sistema voltado para microempreendedores individuais (MEI) que buscam controle organizado de vendas, estoque e financeiro, respeitando as regras do regime do MEI. ⚠️ Não realiza emissão de documentos fiscais.',
    mainBenefits: [
      {
        title: 'Controle de vendas',
        description: 'Registro e acompanhamento das vendas realizadas.'
      },
      {
        title: 'Estoque',
        description: 'Controle de entradas, saídas e saldo de produtos.'
      },
      {
        title: 'PDV ágil',
        description: 'Integração com PIX e balanças, recebimento e troca de mercadorias.'
      },
      {
        title: 'Financeiro',
        description: 'Gestão financeira completa com visão do fluxo de caixa.'
      }
    ],
    resources: [
      'Sem emissão de documentos fiscais',
      'Transações via PIX',
      'Importação de nota de compra',
      'Cadastro rápido de produtos',
      'Balanço de estoque detalhado',
      'Etiquetas personalizáveis'
    ],
    segments: 'Ideal para microempreendedores de diversos segmentos.'
  },
  'g-web': {
    id: 'g-web',
    name: 'G Web',
    price: 'A partir de R$ 59,99',
    subtitle: 'Sistema de gestão online com emissão fiscal para varejo',
    description: 'O G Web é um sistema de gestão online desenvolvido para empresas que buscam mobilidade, controle e conformidade fiscal, com acesso seguro a partir de qualquer dispositivo conectado à internet.',
    mainBenefits: [
      {
        title: 'Gestão centralizada online',
        description: 'Vendas, Estoque, Financeiro e Emissão fiscal integrados.'
      },
      {
        title: 'Financeiro',
        description: 'Gestão integrada de receitas, despesas e movimentações do negócio.'
      },
      {
        title: 'Estoque',
        description: 'Controle de estoque online com acompanhamento em tempo real.'
      },
      {
        title: 'Fiscal e vendas',
        description: 'Emissão online de NF-e, NFC-e, NFS-e, MDF-e e CT-e com envio automático para contabilidade.'
      }
    ],
    resources: [
      'Emissão de documentos fiscais sem limite',
      'Acesso de qualquer lugar',
      'Sem necessidade de servidor local',
      'Multilogin para usuários',
      'Dashboard com indicadores',
      'Atualizações automáticas',
      'PDV híbrido com operação online e offline',
      'Sincronização automática',
      'Integração com TEF, PIX e balanças'
    ],
    segments: 'Atende diferentes modelos de operação no varejo.'
  },
  'g-jatus': {
    id: 'g-jatus',
    name: 'G Jatus',
    price: 'R$ 59,99',
    subtitle: 'Agendamento online para salões, clínicas e barbearias',
    description: 'O G Jatus é um sistema de agendamento online desenvolvido para negócios que trabalham com atendimento por horário. Permite agendamentos 24 horas por dia, melhora a experiência do cliente e facilita a organização da agenda.',
    mainBenefits: [
      {
        title: 'Agendamento online 24h',
        description: 'Facilidade para o cliente marcar horários a qualquer momento.'
      },
      {
        title: 'Lembretes automáticos',
        description: 'Aviso de retorno e notificações automáticas de agendamento.'
      },
      {
        title: 'Controle financeiro',
        description: 'Melhor aproveitamento dos horários com relatórios de comissões.'
      },
      {
        title: 'Organização da rotina',
        description: 'A agenda se torna o ponto central do negócio, auxiliando no planejamento e previsibilidade dos atendimentos.'
      }
    ],
    resources: [
      'Agendamento online 24h',
      'iOS e Android',
      'Lembretes automáticos',
      'Aviso de retorno',
      'Controle financeiro',
      'Relatórios de comissões',
      'Notificações push',
      'Sincronização com servidor'
    ],
    segments: 'Perfeito para salões, clínicas, barbearias e outros negócios com atendimento por horário.'
  },
  'g-exclusive': {
    id: 'g-exclusive',
    name: 'G Exclusive',
    price: 'A partir de R$ 199,99',
    subtitle: 'Soluções digitais exclusivas e personalizadas',
    description: 'O G Exclusive é um serviço totalmente personalizado para empresas que precisam de sites e aplicativos exclusivos, desenvolvidos sob medida.',
    mainBenefits: [
      {
        title: 'Entendimento completo',
        description: 'Entendimento completo da necessidade do cliente.'
      },
      {
        title: 'Planejamento',
        description: 'Planejamento da solução ideal para seu negócio.'
      },
      {
        title: 'Criação exclusiva',
        description: 'Criação de site ou aplicativo exclusivo com funcionalidades desenvolvidas conforme o negócio.'
      },
      {
        title: 'Projeto único',
        description: 'Projeto único, sem modelos prontos, totalmente adaptado à realidade do cliente.'
      }
    ],
    resources: [
      'Sistema próprio',
      'Visual exclusivo',
      'Funcionalidades sob demanda',
      'Total adaptação à realidade do cliente',
      'Desenvolvimento customizado',
      'Design exclusivo',
      'Integração com APIs',
      'Suporte dedicado',
      'Manutenção incluída'
    ],
    segments: 'Ideal para empresas que buscam algo único, profissional e feito sob medida.'
  }
};

export default function SolutionModal({ isOpen, onClose, solution }: SolutionModalProps) {
  if (!isOpen) return null;

  const details = SOLUTIONS_DETAILS[solution.id] || solution;
  // WHATSAPP_NUMERO - Alterar aqui se necessário
  const whatsappLink = `https://wa.me/5575983349174?text=Olá! Gostaria de saber mais sobre o ${details.name}`;

  return (
    <>
      {/* OVERLAY - Fundo escuro */}
      <div
        className="fixed inset-0 bg-black bg-opacity-50 z-40"
        onClick={onClose}
      />

      {/* MODAL */}
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
          
          {/* CABEÇALHO DO MODAL */}
          <div className="bg-gradient-to-r from-orange-600 to-orange-700 text-white p-6 flex items-center justify-between sticky top-0">
            <div className="flex-1">
              <h2 className="text-3xl font-bold mb-2">{details.name}</h2>
              <p className="text-orange-100 text-lg">{details.subtitle}</p>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:bg-orange-700 p-2 rounded-lg transition-colors flex-shrink-0"
            >
              <X size={24} />
            </button>
          </div>

          {/* CORPO DO MODAL */}
          <div className="p-6 space-y-6">
            
            {/* DESCRIÇÃO */}
            <p className="text-gray-700 text-base leading-relaxed">
              {details.description}
            </p>

            {/* PREÇO */}
            <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
              <p className="text-gray-600 text-sm mb-1">Investimento</p>
              <p className="text-3xl font-bold text-orange-600">{details.price}</p>
            </div>

            {/* INFORMAÇÃO IMPORTANTE */}
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
              <p className="text-blue-900 font-semibold mb-2">📌 Informação Importante</p>
              <p className="text-blue-800 text-sm">
                O sistema é <strong>personalizado de acordo com a necessidade do seu negócio</strong>. 
                O valor parte do plano indicado, podendo variar conforme <strong>módulos e recursos adicionais</strong>.
              </p>
            </div>

            {/* BENEFÍCIOS PRINCIPAIS */}
            {details.mainBenefits && details.mainBenefits.length > 0 && (
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">🎯 Principais Benefícios</h3>
                <div className="space-y-4">
                  {details.mainBenefits.map((benefit: any, idx: number) => (
                    <div key={idx} className="border-l-4 border-orange-600 pl-4">
                      <h4 className="font-semibold text-gray-900 mb-1">{benefit.title}</h4>
                      <p className="text-gray-700 text-sm">{benefit.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* RECURSOS DO SISTEMA */}
            {details.resources && details.resources.length > 0 && (
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">✨ Recursos do Sistema</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {details.resources.map((resource: string, idx: number) => (
                    <div key={idx} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                      <span className="text-orange-600 font-bold text-lg flex-shrink-0">✓</span>
                      <span className="text-gray-700 text-sm">{resource}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* SEGMENTOS ATENDIDOS */}
            {details.segments && (
              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <h3 className="text-lg font-bold text-green-900 mb-2">🏢 Segmentos Atendidos</h3>
                <p className="text-green-800 text-sm">{details.segments}</p>
              </div>
            )}

            {/* PRÓXIMOS PASSOS */}
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
              <h3 className="text-lg font-bold text-blue-900 mb-2">📞 Próximos Passos</h3>
              <p className="text-blue-800 text-sm mb-3">
                Um atendente entrará em contato com você pelo WhatsApp para:
              </p>
              <ul className="space-y-1 text-blue-800 text-sm">
                <li>✓ Entender melhor suas necessidades</li>
                <li>✓ Personalizar a solução para seu negócio</li>
                <li>✓ Apresentar um orçamento customizado</li>
                <li>✓ Agendar uma demonstração</li>
              </ul>
            </div>
          </div>

          {/* RODAPÉ DO MODAL */}
          <div className="bg-gray-50 p-6 border-t border-gray-200 flex gap-3 sticky bottom-0">
            <button
              onClick={onClose}
              className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
            >
              Fechar
            </button>
            <a
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 px-6 py-3 bg-orange-600 text-white rounded-lg font-semibold hover:bg-orange-700 transition-colors text-center"
            >
              👉 Fale com um atendente
            </a>
          </div>
        </div>
      </div>
    </>
  );
}
