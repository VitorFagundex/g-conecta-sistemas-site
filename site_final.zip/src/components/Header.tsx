import { useState } from 'react';
import { Menu, X } from 'lucide-react';

/**
 * COMPONENTE: Header
 * 
 * Função: Menu fixo no topo do site com navegação principal
 * 
 * COMO EDITAR:
 * 1. Para alterar itens do menu: procure por "ITENS DO MENU" abaixo
 * 2. Para alterar cores: edite o arquivo client/src/index.css (variáveis --cor-primaria, --cor-secundaria)
 * 3. Para adicionar novo item: adicione um novo objeto no array "menuItems"
 */

interface MenuItem {
  label: string;
  href: string;
}

// ========================================
// ITENS DO MENU - ALTERAR AQUI
// ========================================
const menuItems: MenuItem[] = [
  { label: 'Início', href: '#inicio' },
  { label: 'Soluções', href: '#solucoes' },
  { label: 'Segmentos', href: '#segmentos' },
];

export default function Header() {
  // Estado para controlar menu mobile aberto/fechado
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Função para fechar menu mobile ao clicar em um item
  const handleMenuClick = () => {
    setMobileMenuOpen(false);
  };

  return (
    <>
      {/* HEADER - Menu fixo no topo */}
      <header className="fixed top-0 left-0 right-0 bg-white border-b border-gray-200 z-50 shadow-sm">
        <div className="container">
          <div className="flex items-center justify-between h-16">
            
            {/* LOGO - Alterar aqui se necessário */}
            <div className="flex items-center">
              <a href="#inicio" className="text-xl font-bold text-orange-600">
                G Conecta
              </a>
            </div>

            {/* MENU DESKTOP - Visível apenas em telas grandes */}
            <nav className="hidden md:flex gap-8">
              {menuItems.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  className="text-gray-700 font-medium hover:text-orange-600 transition-colors duration-200"
                >
                  {item.label}
                </a>
              ))}
            </nav>

            {/* BOTÃO WHATSAPP - Desktop */}
            <a
              href="https://wa.me/5575983349174?text=Olá%20G%20Conecta!%20Gostaria%20de%20saber%20mais%20sobre%20seus%20serviços."
              target="_blank"
              rel="noopener noreferrer"
              className="hidden md:inline-block bg-orange-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-orange-700 transition-colors duration-200"
            >
              WhatsApp
            </a>

            {/* BOTÃO MENU MOBILE - Visível apenas em telas pequenas */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 hover:bg-gray-100 rounded-lg transition-colors"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? (
                <X size={24} className="text-gray-700" />
              ) : (
                <Menu size={24} className="text-gray-700" />
              )}
            </button>
          </div>

          {/* MENU MOBILE - Dropdown menu para telas pequenas */}
          {mobileMenuOpen && (
            <nav className="md:hidden border-t border-gray-200 py-4">
              {menuItems.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  onClick={handleMenuClick}
                  className="block px-4 py-2 text-gray-700 hover:bg-gray-100 transition-colors"
                >
                  {item.label}
                </a>
              ))}
              <a
                href="https://wa.me/5575983349174?text=Olá%20G%20Conecta!%20Gostaria%20de%20saber%20mais%20sobre%20seus%20serviços."
                target="_blank"
                rel="noopener noreferrer"
                onClick={handleMenuClick}
                className="block px-4 py-2 text-orange-600 font-medium hover:bg-gray-100 transition-colors"
              >
                WhatsApp
              </a>
            </nav>
          )}
        </div>
      </header>

      {/* Espaço para compensar header fixo */}
      <div className="h-16" />
    </>
  );
}
