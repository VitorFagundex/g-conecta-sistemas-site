/**
 * COMPONENTE: Footer
 * 
 * Função: Rodapé do site com informações de contato e links
 * 
 * COMO EDITAR:
 * 1. Para alterar informações de contato: procure por "INFORMAÇÕES DE CONTATO" abaixo
 * 2. Para alterar links: procure por "LINKS DO FOOTER" abaixo
 * 3. Para alterar cores: edite o arquivo client/src/index.css
 */

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          
          {/* COLUNA 1: Sobre a Empresa */}
          <div>
            <h3 className="text-lg font-bold mb-4 text-orange-600">G Conecta Sistemas</h3>
            <p className="text-gray-400 text-sm">
              Soluções inovadoras em software para transformar seu negócio.
            </p>
          </div>

          {/* COLUNA 2: Links Rápidos */}
          <div>
            <h3 className="text-lg font-bold mb-4">Links Rápidos</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#inicio" className="text-gray-400 hover:text-orange-600 transition-colors">
                  Início
                </a>
              </li>
              <li>
                <a href="#solucoes" className="text-gray-400 hover:text-orange-600 transition-colors">
                  Soluções
                </a>
              </li>
              <li>
                <a href="#segmentos" className="text-gray-400 hover:text-orange-600 transition-colors">
                  Segmentos
                </a>
              </li>
            </ul>
          </div>

          {/* COLUNA 3: Contato */}
          <div>
            <h3 className="text-lg font-bold mb-4">Contato</h3>
            {/* INFORMAÇÕES DE CONTATO - ALTERAR AQUI */}
            <ul className="space-y-2 text-sm">
              <li>
                <a
                  href="https://wa.me/5575983349174"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-orange-600 transition-colors"
                >
                  📱 (75) 98334-9174
                </a>
              </li>
              <li>
                <a
                  href="mailto:contato@gconecta.com"
                  className="text-gray-400 hover:text-orange-600 transition-colors"
                >
                  📧 contato@gconecta.com
                </a>
              </li>
              <li>
                <a
                  href="https://instagram.com/gconectasistema"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-orange-600 transition-colors"
                >
                  📷 @GconectaSistema
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* LINHA DIVISÓRIA */}
        <div className="border-t border-gray-700 pt-8">
          <p className="text-center text-gray-500 text-sm">
            © {currentYear} G Conecta Sistemas. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}
